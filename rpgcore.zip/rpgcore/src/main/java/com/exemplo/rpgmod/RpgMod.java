package com.exemplo.rpgmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.server.network.ServerPlayerEntity;

public class RpgMod implements ModInitializer {
    public static final String MOD_ID = "rpgmod";

    @Override
    public void onInitialize() {
        ModItems.init();
        RpgCommands.init();

        // Aplica os bônus ao entrar no mundo e ao renascer
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.getPlayer();
            RpgLogic.aplicarStats(p, RpgState.get(server).get(p.getUuid()));
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((antigo, novo, vivo) ->
            RpgLogic.aplicarStats(novo, RpgState.get(novo.getServer()).get(novo.getUuid())));

        // XP ao matar monstros
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, fonte) -> {
            if (fonte.getAttacker() instanceof ServerPlayerEntity p && entity instanceof HostileEntity) {
                RpgLogic.darXp(p, Math.max(3, (int) (entity.getMaxHealth() / 2)));
            }
        });

        // Regeneração de mana + barra de ação (1x por segundo)
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) RpgLogic.tickMana(p);
        });
    }
}
