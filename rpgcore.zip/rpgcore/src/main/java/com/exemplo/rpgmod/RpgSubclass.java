package com.exemplo.rpgmod;

import java.util.Arrays;
import java.util.List;

/** Especializações liberadas no nível 20. Cada classe tem 2 caminhos. */
public enum RpgSubclass {
    NENHUMA(null, "Nenhuma", "", 0, 0, 0, 0, 0, 1, 1, 1),

    // classe, nome, descrição, vida, ataque, velocidade, mana, armadura, regen, custo, cooldown
    TEMPESTADE(RpgClass.GUERREIRO, "Senhor da Tempestade", "Martelo invoca 4 raios de uma vez.",
            0, 1.0, 0, 20, 0, 1.3, 1.0, 1.0),
    SENTINELA(RpgClass.GUERREIRO, "Sentinela", "Muita defesa. O martelo também dá Resistência e escudo.",
            6, 0, 0, 0, 4, 1.0, 1.0, 1.0),

    PIROMANTE(RpgClass.MAGO, "Piromante", "+2 bolas de fogo por magia e recarga menor.",
            0, 0, 0, 20, 0, 1.0, 1.0, 0.8),
    CRIOMANTE(RpgClass.MAGO, "Criomante", "Troca o fogo por uma explosão gélida que congela inimigos.",
            0, 0, 0, 30, 0, 1.2, 1.0, 1.0),

    ASSASSINO(RpgClass.LADINO, "Assassino", "Dash com Força e invisibilidade por 10s.",
            0, 2.0, 0.05, 0, 0, 1.0, 1.0, 1.0),
    ACROBATA(RpgClass.LADINO, "Acrobata", "Dash bem mais longo, pulo alto, queda lenta e metade da recarga.",
            0, 0, 0.10, 0, 0, 1.0, 1.0, 0.5),

    CRUZADO(RpgClass.PALADINO, "Cruzado", "Cetro castiga todos os monstros; mortos-vivos sofrem ainda mais.",
            0, 1.5, 0, 0, 0, 1.0, 1.0, 1.0),
    GUARDIAO_SAGRADO(RpgClass.PALADINO, "Guardião Sagrado", "Cura 50% maior, alcance 10 e Resistência nos aliados.",
            6, 0, 0, 0, 3, 1.2, 1.0, 1.0),

    BERSERKER(RpgClass.BARBARO, "Berserker", "Fúria extrema: Força III, Velocidade II e mais dano. Menos armadura.",
            0, 2.0, 0.05, 0, -2, 1.0, 1.0, 1.0),
    TITA(RpgClass.BARBARO, "Titã", "Impacto gigante (alcance 6), Resistência e escudo.",
            10, 0, -0.05, 0, 4, 1.0, 1.0, 1.0),

    ATIRADOR(RpgClass.ARQUEIRO, "Atirador de Elite", "Um único tiro devastador, rápido e preciso. Custa menos mana.",
            0, 1.0, 0, 0, 0, 1.0, 0.8, 1.2),
    RANGER(RpgClass.ARQUEIRO, "Ranger", "Chuva de 5 flechas flamejantes.",
            0, 0, 0.05, 10, 0, 1.0, 1.0, 1.0),

    CEIFADOR(RpgClass.NECROMANTE, "Ceifador", "Drena mais vida, alcance 9 e cura 100% do dano causado.",
            4, 0, 0, 0, 0, 1.0, 1.0, 1.0),
    BRUXO(RpgClass.NECROMANTE, "Bruxo", "Maldições: Wither II, Fraqueza e Cegueira nos inimigos.",
            0, 0, 0, 30, 0, 1.3, 1.0, 1.0),

    GUARDIAO_FLORESTA(RpgClass.DRUIDA, "Guardião da Floresta", "Regeneração III e escudo para todos os aliados.",
            6, 0, 0, 0, 0, 1.3, 1.0, 1.0),
    METAMORFO(RpgClass.DRUIDA, "Metamorfo", "Assume forma bestial: Força, Velocidade, Pulo e Resistência.",
            4, 1.5, 0.10, 0, 0, 1.0, 1.0, 1.0);

    public final RpgClass classe;
    public final String nome, descricao;
    public final double vida, ataque, velocidade, armadura, regen, custo, cooldown;
    public final int mana;

    RpgSubclass(RpgClass classe, String nome, String descricao, double vida, double ataque,
                double velocidade, int mana, double armadura, double regen, double custo, double cooldown) {
        this.classe = classe;
        this.nome = nome;
        this.descricao = descricao;
        this.vida = vida;
        this.ataque = ataque;
        this.velocidade = velocidade;
        this.mana = mana;
        this.armadura = armadura;
        this.regen = regen;
        this.custo = custo;
        this.cooldown = cooldown;
    }

    public static List<RpgSubclass> daClasse(RpgClass c) {
        return Arrays.stream(values()).filter(s -> s.classe == c).toList();
    }

    public static RpgSubclass parse(String s) {
        String alvo = RpgClass.semAcento(s);
        for (RpgSubclass sc : values())
            if (sc != NENHUMA && RpgClass.semAcento(sc.name()).equalsIgnoreCase(alvo)) return sc;
        return null;
    }
}
