package com.exemplo.rpgmod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.tag.EntityTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public final class ModItems {
    private ModItems() {}

    // ---------- helpers ----------
    private static List<LivingEntity> inimigos(ServerWorld w, ServerPlayerEntity p, double raio) {
        return w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(raio),
                e -> e != p && e.isAlive() && e instanceof Monster);
    }

    private static List<PlayerEntity> aliados(ServerWorld w, ServerPlayerEntity p, double raio) {
        return w.getEntitiesByClass(PlayerEntity.class, p.getBoundingBox().expand(raio), e -> e.isAlive());
    }

    private static void particulas(ServerWorld w, ParticleEffect tipo, Vec3d pos, int qtd, double espalhar) {
        w.spawnParticles(tipo, pos.x, pos.y + 1.0, pos.z, qtd, espalhar, espalhar / 2, espalhar, 0.05);
    }

    private static void som(ServerWorld w, ServerPlayerEntity p, SoundEvent s, float pitch) {
        w.playSound(null, p.getBlockPos(), s, SoundCategory.PLAYERS, 1f, pitch);
    }

    private static StatusEffectInstance efeito(net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.effect.StatusEffect> e,
                                               int ticks, int amp) {
        return new StatusEffectInstance(e, ticks, amp, false, true);
    }

    private static Item.Settings um() { return new Item.Settings().maxCount(1); }

    // ---------- itens ----------

    private static void raio(ServerWorld w, BlockPos pos) {
        EntityType.LIGHTNING_BOLT.spawn(w, pos, SpawnReason.TRIGGERED);
    }

    /** Guerreiro: raio. Tempestade = 4 raios. Sentinela = Resistência + escudo. */
    public static final Item MARTELO_TROVAO = registrar("thunder_hammer",
        new SkillItem(um(), RpgClass.GUERREIRO, 30, 80, (w, p, d) -> {
            BlockPos alvo = BlockPos.ofFloored(p.raycast(30.0, 1f, false).getPos());
            raio(w, alvo);
            if (d.sub == RpgSubclass.TEMPESTADE) {
                raio(w, alvo.add(3, 0, 0)); raio(w, alvo.add(-3, 0, 0)); raio(w, alvo.add(0, 0, 3));
            }
            if (d.sub == RpgSubclass.SENTINELA) {
                p.addStatusEffect(efeito(StatusEffects.RESISTANCE, 200, 1));
                p.addStatusEffect(efeito(StatusEffects.ABSORPTION, 200, 1));
            }
        }));

    /** Mago: fogo. Piromante = +2 bolas. Criomante = explosão gélida. */
    public static final Item CAJADO_ARCANO = registrar("arcane_staff",
        new SkillItem(um(), RpgClass.MAGO, 15, 12, (w, p, d) -> {
            if (d.sub == RpgSubclass.CRIOMANTE) {
                DamageSource fonte = w.getDamageSources().indirectMagic(p, p);
                for (LivingEntity e : inimigos(w, p, 6)) {
                    e.damage(fonte, 5 + d.nivel * 0.25f);
                    e.addStatusEffect(efeito(StatusEffects.SLOWNESS, 100, 2));
                    e.setFrozenTicks(200);
                }
                particulas(w, ParticleTypes.SNOWFLAKE, p.getPos(), 80, 3.0);
                som(w, p, SoundEvents.ENTITY_PLAYER_HURT_FREEZE, 1f);
                return;
            }
            int qtd = Math.min(7, 1 + d.nivel / 10 + (d.sub == RpgSubclass.PIROMANTE ? 2 : 0));
            Vec3d olhar = p.getRotationVec(1f);
            for (int i = 0; i < qtd; i++) {
                double ang = (i - (qtd - 1) / 2.0) * 12.0;
                Vec3d dir = olhar.rotateY((float) Math.toRadians(ang));
                SmallFireballEntity fb = new SmallFireballEntity(w, p, dir.multiply(1.5));
                fb.setPosition(p.getX() + dir.x, p.getEyeY() - 0.1 + dir.y, p.getZ() + dir.z);
                w.spawnEntity(fb);
            }
            som(w, p, SoundEvents.ENTITY_BLAZE_SHOOT, 1f);
        }));

    /** Ladino: dash. Assassino = Força + invis longa. Acrobata = dash longo + pulo. */
    public static final Item ADAGA_SOMBRIA = registrar("shadow_dagger",
        new SkillItem(um(), RpgClass.LADINO, 20, 60, (w, p, d) -> {
            boolean assassino = d.sub == RpgSubclass.ASSASSINO, acrobata = d.sub == RpgSubclass.ACROBATA;
            Vec3d o = p.getRotationVec(1f);
            double forca = acrobata ? 2.6 : 1.8;
            p.setVelocity(new Vec3d(o.x, 0, o.z).normalize().multiply(forca).add(0, 0.25, 0));
            p.velocityModified = true;
            p.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(p));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, assassino ? 200 : 100, 0, false, false));
            if (assassino) p.addStatusEffect(efeito(StatusEffects.STRENGTH, 100, 1));
            if (acrobata) {
                p.addStatusEffect(efeito(StatusEffects.JUMP_BOOST, 100, 2));
                p.addStatusEffect(efeito(StatusEffects.SLOW_FALLING, 100, 0));
            }
            p.fallDistance = 0;
            som(w, p, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.4f);
        }));

    /** Paladino: Cruzado castiga monstros; Guardião Sagrado cura mais e mais longe. */
    public static final Item CETRO_SAGRADO = registrar("holy_scepter",
        new SkillItem(um(), RpgClass.PALADINO, 25, 100, (w, p, d) -> {
            boolean cruz = d.sub == RpgSubclass.CRUZADO, guarda = d.sub == RpgSubclass.GUARDIAO_SAGRADO;
            double raio = guarda ? 10 : 6;
            float cura = (6 + d.nivel * 0.2f) * (guarda ? 1.5f : 1f);
            for (PlayerEntity a : aliados(w, p, raio)) {
                a.heal(cura);
                a.addStatusEffect(efeito(StatusEffects.REGENERATION, 100, 0));
                if (guarda) a.addStatusEffect(efeito(StatusEffects.RESISTANCE, 200, 1));
            }
            p.addStatusEffect(efeito(StatusEffects.ABSORPTION, 200, 1));
            DamageSource fonte = w.getDamageSources().indirectMagic(p, p);
            for (LivingEntity e : inimigos(w, p, raio)) {
                boolean morto = e.getType().isIn(EntityTypeTags.UNDEAD);
                if (morto || cruz) {
                    float dano = (morto ? 8 : 5) + d.nivel * 0.3f;
                    if (cruz && morto) dano *= 1.5f;
                    e.damage(fonte, dano);
                    e.setOnFireFor(cruz ? 6 : 4);
                }
            }
            particulas(w, ParticleTypes.END_ROD, p.getPos(), 60, 3.0);
            som(w, p, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.2f);
        }));

    /** Bárbaro: Berserker = fúria extrema. Titã = impacto gigante e defesa. */
    public static final Item MACHADO_FURIA = registrar("rage_axe",
        new SkillItem(um(), RpgClass.BARBARO, 25, 140, (w, p, d) -> {
            boolean berserk = d.sub == RpgSubclass.BERSERKER, tita = d.sub == RpgSubclass.TITA;
            p.addStatusEffect(efeito(StatusEffects.STRENGTH, 200, berserk ? 2 : 1));
            p.addStatusEffect(efeito(StatusEffects.SPEED, 200, berserk ? 1 : 0));
            if (tita) {
                p.addStatusEffect(efeito(StatusEffects.RESISTANCE, 200, 1));
                p.addStatusEffect(efeito(StatusEffects.ABSORPTION, 200, 2));
            }
            DamageSource fonte = w.getDamageSources().playerAttack(p);
            double kbMult = tita ? 1.8 : 1.2;
            for (LivingEntity e : inimigos(w, p, tita ? 6 : 4)) {
                e.damage(fonte, (berserk ? 9 : 6) + d.nivel * 0.3f);
                Vec3d kb = e.getPos().subtract(p.getPos()).normalize().multiply(kbMult);
                e.addVelocity(kb.x, 0.5, kb.z);
                e.velocityModified = true;
            }
            particulas(w, ParticleTypes.EXPLOSION, p.getPos(), 8, tita ? 3.0 : 2.0);
            som(w, p, SoundEvents.ENTITY_RAVAGER_ROAR, tita ? 0.7f : 1f);
        }));

    /** Arqueiro: Atirador = 1 tiro enorme. Ranger = 5 flechas flamejantes. */
    public static final Item ARCO_CACADOR = registrar("hunter_bow",
        new SkillItem(um(), RpgClass.ARQUEIRO, 20, 30, (w, p, d) -> {
            boolean atirador = d.sub == RpgSubclass.ATIRADOR, ranger = d.sub == RpgSubclass.RANGER;
            int[] angulos = atirador ? new int[]{0} : ranger ? new int[]{-12, -6, 0, 6, 12} : new int[]{-6, 0, 6};
            for (int ang : angulos) {
                ArrowEntity flecha = new ArrowEntity(w, p, new ItemStack(Items.ARROW), null);
                flecha.setVelocity(p, p.getPitch(), p.getYaw() + ang, 0f, atirador ? 4.5f : 3.0f, atirador ? 0f : 0.5f);
                flecha.setCritical(true);
                flecha.setDamage(atirador ? 6 + d.nivel * 0.3 : 2.0 + d.nivel * 0.1);
                if (ranger) flecha.setOnFireFor(100);
                flecha.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                w.spawnEntity(flecha);
            }
            p.addStatusEffect(efeito(StatusEffects.SPEED, 60, 1));
            som(w, p, SoundEvents.ENTITY_ARROW_SHOOT, atirador ? 0.7f : 1.2f);
        }));

    /** Necromante: Ceifador drena mais; Bruxo amaldiçoa. */
    public static final Item CAJADO_NECROTICO = registrar("necro_staff",
        new SkillItem(um(), RpgClass.NECROMANTE, 25, 100, (w, p, d) -> {
            boolean ceifador = d.sub == RpgSubclass.CEIFADOR, bruxo = d.sub == RpgSubclass.BRUXO;
            DamageSource fonte = w.getDamageSources().indirectMagic(p, p);
            float dano = (4 + d.nivel * 0.25f) * (ceifador ? 1.5f : bruxo ? 0.5f : 1f);
            float total = 0;
            for (LivingEntity e : inimigos(w, p, ceifador ? 9 : 7)) {
                e.damage(fonte, dano);
                if (bruxo) {
                    e.addStatusEffect(efeito(StatusEffects.WITHER, 200, 1));
                    e.addStatusEffect(efeito(StatusEffects.WEAKNESS, 200, 1));
                    e.addStatusEffect(efeito(StatusEffects.BLINDNESS, 100, 0));
                } else {
                    e.addStatusEffect(efeito(StatusEffects.WITHER, 100, 0));
                }
                particulas(w, ParticleTypes.SOUL, e.getPos(), 12, 0.5);
                total += dano;
            }
            p.heal(total * (ceifador ? 1.0f : 0.5f));
            particulas(w, ParticleTypes.SCULK_SOUL, p.getPos(), 30, 2.0);
            som(w, p, SoundEvents.ENTITY_WITHER_SHOOT, 0.8f);
        }));

    /** Druida: Guardião da Floresta protege aliados; Metamorfo vira fera. */
    public static final Item CAJADO_SELVAGEM = registrar("wild_staff",
        new SkillItem(um(), RpgClass.DRUIDA, 20, 120, (w, p, d) -> {
            boolean guarda = d.sub == RpgSubclass.GUARDIAO_FLORESTA, meta = d.sub == RpgSubclass.METAMORFO;
            for (LivingEntity e : inimigos(w, p, 8)) {
                e.addStatusEffect(efeito(StatusEffects.SLOWNESS, meta ? 60 : 120, meta ? 1 : 2));
                if (!meta) e.addStatusEffect(efeito(StatusEffects.POISON, 100, 1));
            }
            for (PlayerEntity a : aliados(w, p, 8)) {
                a.addStatusEffect(efeito(StatusEffects.REGENERATION, 100, guarda ? 2 : 1));
                if (guarda) a.addStatusEffect(efeito(StatusEffects.ABSORPTION, 200, 1));
            }
            if (meta) {
                p.addStatusEffect(efeito(StatusEffects.STRENGTH, 200, 1));
                p.addStatusEffect(efeito(StatusEffects.SPEED, 200, 1));
                p.addStatusEffect(efeito(StatusEffects.JUMP_BOOST, 200, 1));
                p.addStatusEffect(efeito(StatusEffects.RESISTANCE, 200, 0));
            }
            particulas(w, ParticleTypes.HAPPY_VILLAGER, p.getPos(), 80, 4.0);
            som(w, p, meta ? SoundEvents.ENTITY_WOLF_GROWL : SoundEvents.ENTITY_EVOKER_CAST_SPELL, 1f);
        }));

    private static Item registrar(String id, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(RpgMod.MOD_ID, id), item);
    }

    public static Item itemDaClasse(RpgClass c) {
        return switch (c) {
            case GUERREIRO -> MARTELO_TROVAO;
            case MAGO -> CAJADO_ARCANO;
            case LADINO -> ADAGA_SOMBRIA;
            case PALADINO -> CETRO_SAGRADO;
            case BARBARO -> MACHADO_FURIA;
            case ARQUEIRO -> ARCO_CACADOR;
            case NECROMANTE -> CAJADO_NECROTICO;
            case DRUIDA -> CAJADO_SELVAGEM;
            default -> null;
        };
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> {
            for (RpgClass c : RpgClass.values()) {
                Item i = itemDaClasse(c);
                if (i != null) e.add(i);
            }
        });
    }
}
