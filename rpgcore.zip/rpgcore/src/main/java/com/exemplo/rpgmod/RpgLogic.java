package com.exemplo.rpgmod;

import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class RpgLogic {
    public static final int NIVEL_MAX = 50;
    public static final int NIVEL_SUBCLASSE = 20;

    private RpgLogic() {}

    public static int manaMax(RpgState.Data d) {
        return 50 + d.nivel * 5 + d.classe.manaBonus + d.sub.mana;
    }

    public static int xpNecessario(RpgState.Data d) {
        return 30 + d.nivel * d.nivel * 8;
    }

    public static int custoMana(RpgState.Data d, int base) {
        double mult = (d.classe == RpgClass.MAGO ? 0.6 : 1.0) * d.sub.custo;
        return Math.max(1, (int) Math.ceil(base * mult));
    }

    /** Aplica vida, ataque, armadura e velocidade de acordo com classe, subclasse e nível. */
    public static void aplicarStats(ServerPlayerEntity p, RpgState.Data d) {
        int n = d.nivel - 1;
        mod(p, EntityAttributes.GENERIC_MAX_HEALTH, "bonus_vida",
                d.classe.vidaBase + n * d.classe.vidaPorNivel + d.sub.vida, EntityAttributeModifier.Operation.ADD_VALUE);
        mod(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, "bonus_ataque",
                n * d.classe.ataquePorNivel + d.sub.ataque, EntityAttributeModifier.Operation.ADD_VALUE);
        mod(p, EntityAttributes.GENERIC_ARMOR, "bonus_armadura",
                d.classe.armadura + n * 0.05 + d.sub.armadura, EntityAttributeModifier.Operation.ADD_VALUE);
        mod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, "bonus_velocidade",
                d.classe.velocidade + d.sub.velocidade, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    private static void mod(ServerPlayerEntity p, RegistryEntry<EntityAttribute> attr, String nome,
                            double valor, EntityAttributeModifier.Operation op) {
        EntityAttributeInstance inst = p.getAttributeInstance(attr);
        if (inst == null) return;
        Identifier id = Identifier.of(RpgMod.MOD_ID, nome);
        inst.removeModifier(id);
        if (valor != 0) inst.addPersistentModifier(new EntityAttributeModifier(id, valor, op));
    }

    public static void darXp(ServerPlayerEntity p, int quantidade) {
        RpgState state = RpgState.get(p.getServer());
        RpgState.Data d = state.get(p.getUuid());
        if (d.nivel >= NIVEL_MAX) return;
        int nivelAntes = d.nivel;
        d.xp += quantidade;
        while (d.nivel < NIVEL_MAX && d.xp >= xpNecessario(d)) {
            d.xp -= xpNecessario(d);
            d.nivel++;
        }
        if (d.nivel > nivelAntes) {
            aplicarStats(p, d);
            d.mana = manaMax(d);
            p.setHealth(p.getMaxHealth());
            p.sendMessage(Text.literal("§6§l✦ LEVEL UP! §eVocê agora é nível §f" + d.nivel + "§e!"), false);
            if (nivelAntes < NIVEL_SUBCLASSE && d.nivel >= NIVEL_SUBCLASSE
                    && d.classe != RpgClass.NENHUMA && d.sub == RpgSubclass.NENHUMA) {
                p.sendMessage(Text.literal("§d§l★ Subclasses liberadas! §7Use §f/rpg subclasses §7para ver as opções."), false);
            }
            p.getServerWorld().playSound(null, p.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP,
                    SoundCategory.PLAYERS, 1f, 1f);
        }
        state.markDirty();
    }

    public static void tickMana(ServerPlayerEntity p) {
        RpgState state = RpgState.get(p.getServer());
        RpgState.Data d = state.get(p.getUuid());
        double max = manaMax(d);
        d.mana = Math.min(max, d.mana + (1.5 + d.nivel * 0.1) * d.classe.regenMana * d.sub.regen);
        state.markDirty();
        String titulo = d.sub == RpgSubclass.NENHUMA ? d.classe.nome : d.classe.nome + "/" + d.sub.nome;
        p.sendMessage(Text.literal("§b✦ Mana " + (int) d.mana + "/" + (int) max
                + "  §7| §a" + titulo + " Nv." + d.nivel
                + " §7(" + d.xp + "/" + xpNecessario(d) + " XP)"), true);
    }
}
