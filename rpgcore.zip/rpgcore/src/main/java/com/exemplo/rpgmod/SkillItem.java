package com.exemplo.rpgmod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Item exclusivo de uma classe: gasta mana e lança uma habilidade com o botão direito. */
public class SkillItem extends Item {

    @FunctionalInterface
    public interface Skill {
        void cast(ServerWorld world, ServerPlayerEntity player, RpgState.Data data);
    }

    private final RpgClass classe;
    private final int custoBase;
    private final int cooldownTicks;
    private final Skill skill;

    public SkillItem(Settings settings, RpgClass classe, int custoBase, int cooldownTicks, Skill skill) {
        super(settings);
        this.classe = classe;
        this.custoBase = custoBase;
        this.cooldownTicks = cooldownTicks;
        this.skill = skill;
    }

    public RpgClass getClasse() { return classe; }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient() || !(user instanceof ServerPlayerEntity p)) {
            return TypedActionResult.success(stack);
        }
        ServerWorld sw = (ServerWorld) world;
        RpgState state = RpgState.get(sw.getServer());
        RpgState.Data d = state.get(p.getUuid());

        if (d.classe != classe) {
            p.sendMessage(Text.literal("§cEste item é exclusivo da classe §6" + classe.nome + "§c!"), true);
            return TypedActionResult.fail(stack);
        }
        int custo = RpgLogic.custoMana(d, custoBase);
        if (d.mana < custo) {
            p.sendMessage(Text.literal("§cMana insuficiente! §7(precisa de " + custo + ")"), true);
            return TypedActionResult.fail(stack);
        }
        d.mana -= custo;
        skill.cast(sw, p, d);
        p.getItemCooldownManager().set(this, Math.max(1, (int) (cooldownTicks * d.sub.cooldown)));
        state.markDirty();
        return TypedActionResult.success(stack);
    }
}
