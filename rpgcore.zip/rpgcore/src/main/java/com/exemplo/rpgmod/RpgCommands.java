package com.exemplo.rpgmod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.Arrays;
import java.util.List;

public final class RpgCommands {
    private RpgCommands() {}

    private static List<String> nomes() {
        return Arrays.stream(RpgClass.values()).filter(c -> c != RpgClass.NENHUMA)
                .map(c -> c.name().toLowerCase()).toList();
    }

    private static void darItem(ServerPlayerEntity p, RpgClass c) {
        Item item = ModItems.itemDaClasse(c);
        if (item == null) return;
        ItemStack stack = new ItemStack(item);
        if (!p.getInventory().contains(stack)) p.giveItemStack(stack);
    }

    public static void init() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) ->
            dispatcher.register(CommandManager.literal("rpg")
                .executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    RpgState.Data d = RpgState.get(p.getServer()).get(p.getUuid());
                    p.sendMessage(Text.literal("§6=== Ficha RPG ===\n§eClasse: §f" + d.classe.nome
                            + "\n§eSubclasse: §f" + (d.sub == RpgSubclass.NENHUMA ? "§7nenhuma (libera no nível " + RpgLogic.NIVEL_SUBCLASSE + ")" : d.sub.nome)
                            + "\n§eNível: §f" + d.nivel + " §7(" + d.xp + "/" + RpgLogic.xpNecessario(d) + " XP)"
                            + "\n§eMana: §b" + (int) d.mana + "/" + RpgLogic.manaMax(d)
                            + "\n§7/rpg classes §8- ver classes  §7/rpg classe <nome> §8- escolher  §7/rpg kit §8- pegar item  §7/rpg subclasses"));
                    return 1;
                })
                .then(CommandManager.literal("classes").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    StringBuilder sb = new StringBuilder("§6=== Classes ===");
                    for (RpgClass c : RpgClass.values()) {
                        if (c == RpgClass.NENHUMA) continue;
                        sb.append("\n§e").append(c.nome).append(" §7- ").append(c.descricao);
                    }
                    p.sendMessage(Text.literal(sb.toString()));
                    return 1;
                }))
                .then(CommandManager.literal("subclasses").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    RpgState.Data d = RpgState.get(p.getServer()).get(p.getUuid());
                    if (d.classe == RpgClass.NENHUMA) {
                        p.sendMessage(Text.literal("§cEscolha uma classe primeiro: /rpg classe <nome>"));
                        return 0;
                    }
                    StringBuilder sb = new StringBuilder("§6=== Subclasses de " + d.classe.nome
                            + " §7(nível " + RpgLogic.NIVEL_SUBCLASSE + ") §6===");
                    for (RpgSubclass sc : RpgSubclass.daClasse(d.classe)) {
                        sb.append("\n§e").append(sc.nome).append(" §8[").append(sc.name().toLowerCase()).append("] §7- ").append(sc.descricao);
                    }
                    sb.append("\n§7Escolha com §f/rpg subclasse <nome>");
                    p.sendMessage(Text.literal(sb.toString()));
                    return 1;
                }))
                .then(CommandManager.literal("subclasse")
                    .then(CommandManager.argument("nome", StringArgumentType.word())
                        .suggests((c, b) -> CommandSource.suggestMatching(
                                Arrays.stream(RpgSubclass.values()).filter(s -> s != RpgSubclass.NENHUMA)
                                        .map(s -> s.name().toLowerCase()).toList(), b))
                        .executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            RpgState state = RpgState.get(p.getServer());
                            RpgState.Data d = state.get(p.getUuid());
                            RpgSubclass sc = RpgSubclass.parse(StringArgumentType.getString(ctx, "nome"));
                            if (sc == null) {
                                p.sendMessage(Text.literal("§cSubclasse inválida. Use /rpg subclasses."));
                                return 0;
                            }
                            if (d.nivel < RpgLogic.NIVEL_SUBCLASSE) {
                                p.sendMessage(Text.literal("§cVocê precisa do nível " + RpgLogic.NIVEL_SUBCLASSE
                                        + " §7(atual: " + d.nivel + ")"));
                                return 0;
                            }
                            if (sc.classe != d.classe) {
                                p.sendMessage(Text.literal("§cEssa subclasse pertence ao §6" + sc.classe.nome + "§c."));
                                return 0;
                            }
                            d.sub = sc;
                            d.mana = RpgLogic.manaMax(d);
                            RpgLogic.aplicarStats(p, d);
                            state.markDirty();
                            p.sendMessage(Text.literal("§d★ Você se tornou §6" + sc.nome + "§d! §7" + sc.descricao));
                            return 1;
                        })))
                .then(CommandManager.literal("kit").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    RpgState.Data d = RpgState.get(p.getServer()).get(p.getUuid());
                    if (d.classe == RpgClass.NENHUMA) {
                        p.sendMessage(Text.literal("§cEscolha uma classe primeiro: /rpg classe <nome>"));
                        return 0;
                    }
                    darItem(p, d.classe);
                    return 1;
                }))
                .then(CommandManager.literal("classe")
                    .then(CommandManager.argument("nome", StringArgumentType.word())
                        .suggests((c, b) -> CommandSource.suggestMatching(nomes(), b))
                        .executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            RpgClass c = RpgClass.parse(StringArgumentType.getString(ctx, "nome"));
                            if (c == null || c == RpgClass.NENHUMA) {
                                p.sendMessage(Text.literal("§cClasse inválida. Use /rpg classes para ver a lista."));
                                return 0;
                            }
                            RpgState state = RpgState.get(p.getServer());
                            RpgState.Data d = state.get(p.getUuid());
                            d.classe = c;
                            d.sub = RpgSubclass.NENHUMA;
                            d.mana = RpgLogic.manaMax(d);
                            RpgLogic.aplicarStats(p, d);
                            state.markDirty();
                            darItem(p, c);
                            p.sendMessage(Text.literal("§aAgora você é um §6" + c.nome + "§a! §7" + c.descricao));
                            return 1;
                        })))
                .then(CommandManager.literal("darxp")
                    .requires(s -> s.hasPermissionLevel(2))
                    .then(CommandManager.argument("qtd", IntegerArgumentType.integer(1))
                        .executes(ctx -> {
                            RpgLogic.darXp(ctx.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(ctx, "qtd"));
                            return 1;
                        })))));
    }
}
