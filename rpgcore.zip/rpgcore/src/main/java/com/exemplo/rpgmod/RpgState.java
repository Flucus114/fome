package com.exemplo.rpgmod;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Guarda os dados RPG de todos os jogadores no mundo (salvo automaticamente). */
public class RpgState extends PersistentState {

    public static class Data {
        public RpgClass classe = RpgClass.NENHUMA;
        public RpgSubclass sub = RpgSubclass.NENHUMA;
        public int nivel = 1;
        public int xp = 0;
        public double mana = 50;
    }

    private final Map<UUID, Data> jogadores = new HashMap<>();

    public Data get(UUID id) {
        return jogadores.computeIfAbsent(id, k -> new Data());
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        NbtCompound todos = new NbtCompound();
        jogadores.forEach((id, d) -> {
            NbtCompound t = new NbtCompound();
            t.putString("classe", d.classe.name());
            t.putString("sub", d.sub.name());
            t.putInt("nivel", d.nivel);
            t.putInt("xp", d.xp);
            t.putDouble("mana", d.mana);
            todos.put(id.toString(), t);
        });
        nbt.put("jogadores", todos);
        return nbt;
    }

    public static RpgState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        RpgState state = new RpgState();
        NbtCompound todos = nbt.getCompound("jogadores");
        for (String key : todos.getKeys()) {
            NbtCompound t = todos.getCompound(key);
            Data d = new Data();
            RpgClass c = RpgClass.parse(t.getString("classe"));
            d.classe = c == null ? RpgClass.NENHUMA : c;
            try { d.sub = RpgSubclass.valueOf(t.getString("sub")); } catch (IllegalArgumentException ignored) {}
            if (d.sub.classe != null && d.sub.classe != d.classe) d.sub = RpgSubclass.NENHUMA;
            d.nivel = Math.max(1, t.getInt("nivel"));
            d.xp = t.getInt("xp");
            d.mana = t.getDouble("mana");
            state.jogadores.put(UUID.fromString(key), d);
        }
        return state;
    }

    private static final PersistentState.Type<RpgState> TYPE =
            new PersistentState.Type<>(RpgState::new, RpgState::fromNbt, null);

    public static RpgState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "rpgmod");
    }
}
