package com.exemplo.rpgmod;

public enum RpgClass {
    //            nome            vidaBase vidaNv atkNv  vel    mana regen armor  descrição
    NENHUMA     ("Aventureiro",   0, 1.0, 0.00,  0.00,   0, 1.0, 0, "Sem classe."),
    GUERREIRO   ("Guerreiro",     4, 1.5, 0.25,  0.00,   0, 0.8, 1, "Tanque equilibrado. Martelo do Trovão: invoca raios."),
    MAGO        ("Mago",          0, 0.5, 0.00,  0.00,  50, 2.0, 0, "Muita mana, magias baratas. Cajado Arcano: bolas de fogo."),
    LADINO      ("Ladino",        0, 1.0, 0.15,  0.15,   0, 1.2, 0, "Rápido e letal. Adaga Sombria: dash + invisibilidade."),
    PALADINO    ("Paladino",      4, 1.5, 0.10, -0.05,  10, 1.0, 3, "Armadura pesada. Cetro Sagrado: cura aliados e queima mortos-vivos."),
    BARBARO     ("Bárbaro",       8, 2.0, 0.30,  0.05,   0, 0.6, 0, "Vida e dano enormes. Machado da Fúria: fúria + impacto em área."),
    ARQUEIRO    ("Arqueiro",      0, 1.0, 0.10,  0.10,  20, 1.3, 0, "Ágil à distância. Arco do Caçador: rajada de 3 flechas."),
    NECROMANTE  ("Necromante",    0, 0.75, 0.00, 0.00,  40, 1.6, 0, "Drena vida. Cajado Necrótico: suga vida dos inimigos."),
    DRUIDA      ("Druida",        2, 1.25, 0.00, 0.05,  30, 1.5, 0, "Natureza. Cajado Selvagem: prende inimigos e regenera aliados.");

    public final String nome;
    public final double vidaBase, vidaPorNivel, ataquePorNivel, velocidade, regenMana, armadura;
    public final int manaBonus;
    public final String descricao;

    RpgClass(String nome, double vidaBase, double vidaPorNivel, double ataquePorNivel, double velocidade,
             int manaBonus, double regenMana, double armadura, String descricao) {
        this.nome = nome;
        this.vidaBase = vidaBase;
        this.vidaPorNivel = vidaPorNivel;
        this.ataquePorNivel = ataquePorNivel;
        this.velocidade = velocidade;
        this.manaBonus = manaBonus;
        this.regenMana = regenMana;
        this.armadura = armadura;
        this.descricao = descricao;
    }

    /** Aceita "barbaro" e "bárbaro". */
    public static RpgClass parse(String s) {
        String alvo = semAcento(s);
        for (RpgClass c : values()) if (semAcento(c.name()).equalsIgnoreCase(alvo)) return c;
        return null;
    }

    static String semAcento(String s) {
        return java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }
}
